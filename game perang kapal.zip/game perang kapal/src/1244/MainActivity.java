<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dual Shoot + Nyawa + Audio Respawn</title>
<style>
html, body { margin:0; padding:0; height:100%; overflow:hidden; background:#87ceeb; font-family:sans-serif; user-select:none; touch-action:none; }
.element { position:absolute; width:100px; height:100px; border-radius:20px; color:white; font-weight:bold; display:flex; flex-direction:column; justify-content:center; align-items:center; cursor:pointer; z-index:1; }
#left { top:300px; left:20px; background:transparent; border:none;}
#left img { width:100%; height:100%; object-fit:contain; }
#right { top:300px; right:20px; background:transparent; border:none;}
#right img { width:100%; height:100%; object-fit:contain; }
#top { top:50px; left:50%; transform:translateX(-50%) scale(0.1); opacity:0; transition: transform 0.3s, opacity 0.3s; z-index:1; background:#ff6347;}
.bullet { position:absolute; width:60px; height:60px; z-index:2;}
.bullet img { width:100%; height:100%; object-fit:contain; display:block; pointer-events:none; }
.controls { position:fixed; bottom:20px; left:50%; transform:translateX(-50%); z-index:10;}
button { padding:10px 20px; font-size:16px; cursor:pointer;}
.hp-text { font-size:14px; margin-top:5px; }
.blink { animation: blink 0.3s step-start infinite; }
@keyframes blink { 50% { opacity:0; } 100% { opacity:1; } }
</style>
</head>
<body>

<div class="element" id="left">
  <img src="https://raw.githubusercontent.com/hantucinta/mentahan-project-game/refs/heads/main/Proyek%20Baru%202%20%5B8CA31B7%5D.png" alt="Left Character">
  <div class="hp-text" id="leftHPText">100</div>
</div>

<div class="element" id="right">
  <img src="https://raw.githubusercontent.com/hantucinta/mentahan-project-game/refs/heads/main/Proyek%20Baru%202%20%5B90FA073%5D.png" alt="Right Character">
  <div class="hp-text" id="rightHPText">100</div>
</div>

<div class="element" id="top">Atas</div>

<div class="controls">
  <button onclick="growTop()">Animasi Atas</button>
</div>

<script>
const topElement = document.getElementById('top');
const leftElement = document.getElementById('left');
const rightElement = document.getElementById('right');
const leftHPText = document.getElementById('leftHPText');
const rightHPText = document.getElementById('rightHPText');

let leftShootAudio = new Audio("https://github.com/hantucinta/mentahan-project-game/raw/refs/heads/main/lv_0_20251206151424.mp3");
let rightShootAudio = new Audio("https://github.com/hantucinta/mentahan-project-game/raw/refs/heads/main/lv_0_20251206130849.mp3");
let respawnAudio = new Audio("https://github.com/hantucinta/mentahan-project-game/raw/refs/heads/main/lv_0_20251206131428.mp3");

let leftStage=1, rightStage=1;
let leftShots=0, rightShots=0;
let leftAlive=true, rightAlive=true;

function getShotsForStage(stage){
  if(stage===1) return 1;
  if(stage===2) return 5;
  return Math.min((stage-1)*5,100);
}
function resetStage(stageVar){ return stageVar>=21 ? 1 : stageVar+1; }

function growTop() {
  topElement.style.transform = "translateX(-50%) scale(0.1)";
  topElement.style.opacity = "0";
  setTimeout(() => {
    topElement.style.transform = "translateX(-50%) scale(1)";
    topElement.style.opacity = "1";
  }, 50);
}

function handleRespawn(targetElement,targetSide){
  targetElement.classList.add('blink');
  respawnAudio.currentTime=0;
  respawnAudio.play();
  setTimeout(()=>{
    if(targetSide==='left'){ leftAlive=true; leftStage=resetStage(leftStage); leftShots=0; leftHPText.textContent="100"; }
    if(targetSide==='right'){ rightAlive=true; rightStage=resetStage(rightStage); rightShots=0; rightHPText.textContent="100"; }
    targetElement.classList.remove('blink');
  },3000);
}

function shoot(shooter,target,audioObj,targetSide){
  if((targetSide==='left' && !leftAlive) || (targetSide==='right' && !rightAlive)) return;

  audioObj.currentTime=0;
  audioObj.play();

  const bullet=document.createElement('div');
  bullet.classList.add('bullet');
  
  const bulletImg=document.createElement('img');
  if(shooter===leftElement){
    bulletImg.src='https://raw.githubusercontent.com/hantucinta/mentahan-project-game/refs/heads/main/Proyek%20Baru%203%20%5BB00652A%5D.png';
    bulletImg.alt='Left Bullet';
  } else {
    bulletImg.src='https://raw.githubusercontent.com/hantucinta/mentahan-project-game/refs/heads/main/Proyek%20Baru%203%20%5B3FDE9A7%5D.png';
    bulletImg.alt='Right Bullet';
  }
  bullet.appendChild(bulletImg);

  const shooterRect=shooter.getBoundingClientRect();
  const targetRect=target.getBoundingClientRect();

  let posX, posY;
  
  if(shooter===leftElement){
    posX=shooterRect.right - 30;
    posY=shooterRect.top + shooterRect.height/2 - 30;
  } else {
    posX=shooterRect.left - 30;
    posY=shooterRect.top + shooterRect.height/2 - 30;
  }

  const targetX=targetRect.left + targetRect.width/2 - 30;
  const targetY=targetRect.top + targetRect.height/2 - 30;

  bullet.style.left=posX+'px';
  bullet.style.top=posY+'px';
  document.body.appendChild(bullet);

  const interval=setInterval(()=>{
    posX+=(targetX-posX)*0.1;
    posY+=(targetY-posY)*0.1;
    bullet.style.left=posX+'px';
    bullet.style.top=posY+'px';

    if(Math.abs(posX-targetX)<1 && Math.abs(posY-targetY)<1){
      bullet.remove();
      clearInterval(interval);

      if(targetSide==='left'){
        leftShots++;
        let shotsNeeded=getShotsForStage(leftStage);
        let hpValue=Math.max(0,Math.round(100-(leftShots/shotsNeeded)*100));
        leftHPText.textContent=hpValue;
        if(leftShots>=shotsNeeded && leftAlive){
          leftAlive=false;
          handleRespawn(leftElement,'left');
        }
      } else if(targetSide==='right'){
        rightShots++;
        let shotsNeeded=getShotsForStage(rightStage);
        let hpValue=Math.max(0,Math.round(100-(rightShots/shotsNeeded)*100));
        rightHPText.textContent=hpValue;
        if(rightShots>=shotsNeeded && rightAlive){
          rightAlive=false;
          handleRespawn(rightElement,'right');
        }
      }
    }
  },20);
}

let leftPressed=false;
let rightPressed=false;
let shootInterval=null;

function handleShoot(){
  if(leftPressed) shoot(leftElement,rightElement,rightShootAudio,'right');
  if(rightPressed) shoot(rightElement,leftElement,leftShootAudio,'left');
}

function startShooting(){
  if(shootInterval) clearInterval(shootInterval);
  handleShoot();
  shootInterval = setInterval(handleShoot, 200);
}

function stopShooting(){
  if(!leftPressed && !rightPressed){
    if(shootInterval){
      clearInterval(shootInterval);
      shootInterval=null;
    }
  }
}

leftElement.addEventListener('pointerdown',(e)=>{ 
  e.preventDefault();
  leftPressed=true; 
  startShooting(); 
});
leftElement.addEventListener('pointerup',(e)=>{ 
  e.preventDefault();
  leftPressed=false; 
  stopShooting();
});
leftElement.addEventListener('pointerleave',(e)=>{ 
  leftPressed=false; 
  stopShooting();
});
leftElement.addEventListener('touchstart',(e)=>{ 
  e.preventDefault();
  leftPressed=true; 
  startShooting(); 
}, {passive:false});
leftElement.addEventListener('touchend',(e)=>{ 
  e.preventDefault();
  leftPressed=false; 
  stopShooting();
}, {passive:false});

rightElement.addEventListener('pointerdown',(e)=>{ 
  e.preventDefault();
  rightPressed=true; 
  startShooting(); 
});
rightElement.addEventListener('pointerup',(e)=>{ 
  e.preventDefault();
  rightPressed=false; 
  stopShooting();
});
rightElement.addEventListener('pointerleave',(e)=>{ 
  rightPressed=false; 
  stopShooting();
});
rightElement.addEventListener('touchstart',(e)=>{ 
  e.preventDefault();
  rightPressed=true; 
  startShooting(); 
}, {passive:false});
rightElement.addEventListener('touchend',(e)=>{ 
  e.preventDefault();
  rightPressed=false; 
  stopShooting();
}, {passive:false});
</script>
</body>
</html>